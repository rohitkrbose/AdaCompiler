# AdaCompiler

Go to ./src/ and run the following commands. <br />
python3 parser.py ../tests/input/arithmetic.adb <br />
Dumps are created as 3_AC_dump.csv, SymTab_dump.csv in ./output directory