# AdaCompiler

Go to ./src/ and run the following commands. <br />
python3 parser.py ../tests/input/fibonacci.adb --out=fibonacci.dot <br />
dot -Tpng fibonacci.dot > output.png <br />